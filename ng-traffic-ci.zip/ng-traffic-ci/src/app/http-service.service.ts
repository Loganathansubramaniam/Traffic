import "rxjs/add/operator/map";
import {Injectable} from "@angular/core";
import {Http} from "@angular/http";

@Injectable()
export class HttpService {
	constructor(private _http: Http) {
	}

	httpGet() {
		return this._http.get("http://traffic-env.6md8k329pt.us-east-1.elasticbeanstalk.com/getTrafficInfo")
      .map(res => res.json());
	}

}
