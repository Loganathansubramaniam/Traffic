import { Component, OnInit,NgZone } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/interval';
import { TrafficLightService, LIGHT_STATES } from './traffic-light.service';
import {HttpService} from './http-service.service';
import {Traffic} from './traffic';
import {startWith} from 'rxjs/operators'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [HttpService]
})
export class AppComponent implements OnInit {
  title = 'Smart Signal';
  trafficLightState: string;
  traffic: Traffic[];
  northDir: string;
  southDir: string;
  eastDir: string;
  westDir: string;
  private _timer;
  noOfVehiclesEast: number;
  noOfVehiclesWest: number;
  noOfVehiclesNorth: number;
  noOfVehiclesSouth: number;
  isThresholdReachedE: boolean;
  isThresholdReachedW: boolean;
  isThresholdReachedN: boolean;
  isThresholdReachedS: boolean;
  ambulanceFoundE: boolean;
  ambulanceFoundW: boolean;
  ambulanceFoundN: boolean;
  ambulanceFoundS: boolean;
  constructor(private trafficService: TrafficLightService,private http: HttpService,private ngZone: NgZone) {
  }

  ngOnInit() {
    Observable
	.interval(15000)
	.pipe(startWith(0))
	.subscribe(
	 data=> {
		this.getResponse();
    });
	
  }

  getResponse() {
  this.http.httpGet().subscribe(response => {
	this.traffic = response;
	for (let i=0; i<this.traffic.length; i++) {
		console.log(this.traffic);
		switch(this.traffic[i].signalDirection) {
			case "East":
				this.noOfVehiclesEast = this.traffic[i].noOfVehicles;
				this.isThresholdReachedE = this.traffic[i].isThresholdReached;
				this.ambulanceFoundE = this.traffic[i].ambulanceFound;
				break;
			case "West":
				this.noOfVehiclesWest = this.traffic[i].noOfVehicles;
				this.isThresholdReachedW = this.traffic[i].isThresholdReached;
				this.ambulanceFoundW = this.traffic[i].ambulanceFound;
				break;
			case "North":
				this.noOfVehiclesNorth = this.traffic[i].noOfVehicles;
				this.isThresholdReachedN = this.traffic[i].isThresholdReached;
				this.ambulanceFoundN = this.traffic[i].ambulanceFound;
				break;
			case "South":
				this.noOfVehiclesSouth = this.traffic[i].noOfVehicles;
				this.isThresholdReachedS = this.traffic[i].isThresholdReached;
				this.ambulanceFoundS = this.traffic[i].ambulanceFound;
				break;				
			
		}
	}
	this.northDir = this.traffic[0].signalDirection;
	if(this.traffic[0].signalDirection == 'North'){
	this.northDir = 'green';
	this.southDir = 'red';
	this.eastDir = 'red';
	this.westDir = 'red';
	}else if(this.traffic[0].signalDirection == 'South'){
	this.northDir = 'red';
	this.southDir = 'green';
	this.eastDir = 'red';
	this.westDir = 'red';
	}else if(this.traffic[0].signalDirection == 'West'){
	this.northDir = 'red';
	this.southDir = 'red';
	this.eastDir = 'red';
	this.westDir = 'green';
	}else{
	this.northDir = 'red';
	this.southDir = 'red';
	this.eastDir = 'green';
	this.westDir = 'red';
	}
		console.log(this.traffic[0]);
	});
  }
  
  /**
   * @author Ahsan Ayaz
   * The function gets triggered on STOP button click.
   * Disables the auto method and shows the Red Light
   */
  stop() {
    this.trafficService.setState(LIGHT_STATES.STOP);
  }

  /**
   * @author Ahsan Ayaz
   * The function gets triggered on READY button click.
   * Disables the auto method and shows the Yello Light
   */
  ready() {
    this.trafficService.setState(LIGHT_STATES.READY);
  }

  /**
   * @author Ahsan Ayaz
   * The function gets triggered on GO button click.
   * Disables the auto method and shows the Green Light
   */
  go() {
    this.trafficService.setState(LIGHT_STATES.GO);
  }

  /**
   * @author Ahsan Ayaz
   * The function gets triggered on AUTO button click.
   * Resets the signal to auto method which changes the state
   * of the signal using timeouts
   */
  auto() {
    this.trafficService.resetSignalToAuto();
  }

}
