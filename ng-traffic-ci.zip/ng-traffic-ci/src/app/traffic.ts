
export class Traffic {
	isGreen: boolean;
	limit: number;
	signalDirection: string;
	noOfVehicles: number;
	isThresholdReached: boolean;
	ambulanceFound: boolean;
}
