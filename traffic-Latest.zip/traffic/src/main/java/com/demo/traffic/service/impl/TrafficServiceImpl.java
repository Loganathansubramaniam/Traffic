package com.demo.traffic.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Service;

import com.demo.traffic.config.TrafficConfiguration;
import com.demo.traffic.model.Signal;
import com.demo.traffic.model.TrafficModel;
import com.demo.traffic.service.TrafficService;

@Service
public class TrafficServiceImpl implements TrafficService{
	
	@Autowired
	private CacheManager cacheManager;
	
	@Autowired
	private TrafficConfiguration trafficConfig;

	@Override
	public Queue<Signal> getTrafficQueue() {
		TrafficModel tm = (TrafficModel) cacheManager.getCache("signal");
		Signal tempSignal = null; 
		int count = 0;
		if(tm.getQueue().size() == 0){
			Queue<Signal> ct = getCurrentTraffic(tm);
			ct.peek().setCount(1);
			cacheManager.getCache("signal").put("traffic", ct);
		}else{
			Queue<Signal> cachedTraffic = sortQueue(convertToQueueOfSignal());
			int cnt = cachedTraffic.peek().getCount();
			//clear the cache
			cacheManager.getCache("signal").clear();
			
			TrafficModel t = new TrafficModel("signal");
			//Queue<Signal> currentTraffic = sortQueue(getCurrentTraffic(t));
			Queue<Signal> currentTraffic = sortQueue(updateCache(cachedTraffic));
			
			if(cachedTraffic.peek().getSignalDirection().equalsIgnoreCase(currentTraffic.peek().getSignalDirection())){
				if(currentTraffic.peek().getLimit() >= trafficConfig.getLimitPerDirection()){
					Signal temp = currentTraffic.poll();//Remove from the queue as limit reached. Preference to be given to other directions
					temp.setThresholdReached(true);
					currentTraffic.peek().setGreen(true);//Make the next entry in the queue direction as green
					currentTraffic.add(temp);
					tempSignal = temp;
					System.out.println("queue removed:"+ currentTraffic.size());
				}else{
					currentTraffic.peek().setLimit(currentTraffic.peek().getLimit()+1);
				}
			}
			currentTraffic.peek().setCount(cnt+1);
			count = currentTraffic.peek().getCount();
			cacheManager.getCache("signal").put("traffic", currentTraffic);
		}
		Queue<Signal> finalQ = sortQueue(convertToQueueOfSignal());
		if(tempSignal != null) {
			finalQ.add(tempSignal);
		}
		if(count % 4 == 0) {
			Signal temp = finalQ.poll();
			finalQ.peek().setAmbulanceFound(true);
			finalQ.add(temp);
		}
		//clear the cache
		//cacheManager.getCache("signal").clear();
		//cacheManager.getCache("signal").put("traffic", finalQ);
		return finalQ;
	}
	
	private Queue<Signal> convertToQueueOfSignal(){
		Queue<Signal> queueSignal = new LinkedList<>();
		
		@SuppressWarnings("unchecked")
		ConcurrentHashMap<Object, Object>  signalMap = (ConcurrentHashMap<Object, Object>)cacheManager.getCache("signal").getNativeCache();
		for(Map.Entry<Object, Object> entry : signalMap.entrySet()){
			@SuppressWarnings("unchecked")
			LinkedList<Signal> signalLL = (LinkedList<Signal>) entry.getValue();
			for(Signal signal : signalLL){
				queueSignal.add(signal);
			}
		}
		return queueSignal;
	}
	
	private Queue<Signal> sortQueue(Queue<Signal> finalQueue) {
		List<Signal> signalList = new ArrayList<>();
		for(Signal s : finalQueue){
			signalList.add(s);
		}
		Collections.sort(signalList, new Signal());
		return new LinkedList<>(signalList);
	}

	private Queue<Signal> getCurrentTraffic(TrafficModel trafficModel){
		Queue<Signal> trafficQueue = trafficModel.getQueue();
		updateTrafficQueue(trafficQueue);
		List<Signal> signalList = new ArrayList<>();
		for(Signal q : trafficQueue){
			Random random = new Random();
			q.setNoOfVehicles(random.nextInt(trafficConfig.getRandomNumberConfig()));
			q.setLimit(q.getLimit()+1);
			signalList.add(q);
		}
		Collections.sort(signalList, new Signal());
		Queue<Signal> finalQueue = new LinkedList<>(signalList);
		finalQueue.peek().setGreen(true);
		return finalQueue;
	}
	
	private void updateTrafficQueue(Queue<Signal> queue){
		Signal s1 = new Signal("East");
		Signal s2 = new Signal("West");
		Signal s3 = new Signal("North");
		Signal s4 = new Signal("South");
		queue.add(s1);
		queue.add(s2);
		queue.add(s3);
		queue.add(s4);
	}
	
	private Queue<Signal> updateCache(Queue<Signal> cachedTraffic){
		List<Signal> signalList = new ArrayList<>();
		int i = 0;
		for(Signal s : cachedTraffic){
			Random random = new Random();
			int rn = random.nextInt(trafficConfig.getRandomNumber());
			if(i == 0) {
				if(s.getNoOfVehicles() >= rn) {
					s.setNoOfVehicles(s.getNoOfVehicles()-rn);
				}
			}else {
				s.setNoOfVehicles(s.getNoOfVehicles()+rn);
			}
			s.setThresholdReached(false);
			s.setAmbulanceFound(false);
			i++;
			signalList.add(s);
		}
		Collections.sort(signalList, new Signal());
		Queue<Signal> finalQueue = new LinkedList<>(signalList);
		finalQueue.peek().setGreen(true);

		return finalQueue;
	}

}
