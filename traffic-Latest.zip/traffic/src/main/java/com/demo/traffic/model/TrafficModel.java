package com.demo.traffic.model;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.Queue;

import org.springframework.cache.concurrent.ConcurrentMapCache;

public class TrafficModel extends ConcurrentMapCache implements Serializable{

	public TrafficModel(String name) {
		super(name);
	}
	private static final long serialVersionUID = 1L;
	
	private Queue<Signal> queue = new LinkedList<>();
	
	public Queue<Signal> getQueue() {
		return queue;
	}
	
}
