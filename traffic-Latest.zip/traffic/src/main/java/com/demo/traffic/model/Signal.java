package com.demo.traffic.model;

import java.io.Serializable;
import java.util.Comparator;

public class Signal implements Serializable, Comparator<Signal>{

	private static final long serialVersionUID = 1L;
	
	private boolean isGreen = false;
	private int limit = 0;
	private String signalDirection;
	private int noOfVehicles;
	private boolean isThresholdReached = false;
	private boolean ambulanceFound = false;
	private int count = 0;
	
	public Signal(){
		
	}
	public Signal(String signalDirection) {
		super();
		this.signalDirection = signalDirection;
	}
	public boolean isGreen() {
		return isGreen;
	}
	public void setGreen(boolean isGreen) {
		this.isGreen = isGreen;
	}
	public int getLimit() {
		return limit;
	}
	public void setLimit(int limit) {
		this.limit = limit;
	}
	public String getSignalDirection() {
		return signalDirection;
	}
	public void setSignalDirection(String signalDirection) {
		this.signalDirection = signalDirection;
	}
	public int getNoOfVehicles() {
		return noOfVehicles;
	}
	public void setNoOfVehicles(int noOfVehicles) {
		this.noOfVehicles = noOfVehicles;
	}
	
	public boolean isThresholdReached() {
		return isThresholdReached;
	}
	public void setThresholdReached(boolean isThresholdReached) {
		this.isThresholdReached = isThresholdReached;
	}
	public boolean isAmbulanceFound() {
		return ambulanceFound;
	}
	public void setAmbulanceFound(boolean ambulanceFound) {
		this.ambulanceFound = ambulanceFound;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	@Override
	public int compare(Signal s1, Signal s2) {
		return Integer.compare(s2.noOfVehicles, s1.noOfVehicles);
	}
	
	
	
}
