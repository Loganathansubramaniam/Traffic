package com.demo.traffic.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties
public class TrafficConfiguration {
	
	@Value("${limitPerDirection}")
	private int limitPerDirection;
	
	@Value("${randomNumberConfig}")
	private int randomNumberConfig;
	
	@Value("${randomNumber}")
	private int randomNumber;

	public int getLimitPerDirection() {
		return limitPerDirection;
	}

	public void setLimitPerDirection(int limitPerDirection) {
		this.limitPerDirection = limitPerDirection;
	}

	public int getRandomNumberConfig() {
		return randomNumberConfig;
	}

	public void setRandomNumberConfig(int randomNumberConfig) {
		this.randomNumberConfig = randomNumberConfig;
	}

	public int getRandomNumber() {
		return randomNumber;
	}

	public void setRandomNumber(int randomNumber) {
		this.randomNumber = randomNumber;
	}

	
	
}
