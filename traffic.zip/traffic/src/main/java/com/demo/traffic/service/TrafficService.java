package com.demo.traffic.service;

import java.util.Queue;

import com.demo.traffic.model.Signal;

public interface TrafficService {
	
	Queue<Signal> getTrafficQueue();

}
