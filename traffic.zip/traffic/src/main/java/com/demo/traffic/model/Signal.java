package com.demo.traffic.model;

import java.io.Serializable;
import java.util.Comparator;

public class Signal implements Serializable, Comparator<Signal>{

	private static final long serialVersionUID = 1L;
	
	private boolean isGreen = false;
	private int limit = 0;
	private String signalDirection;
	private int noOfVehicles;
	
	public Signal(){
		
	}
	public Signal(String signalDirection) {
		super();
		this.signalDirection = signalDirection;
	}
	public boolean isGreen() {
		return isGreen;
	}
	public void setGreen(boolean isGreen) {
		this.isGreen = isGreen;
	}
	public int getLimit() {
		return limit;
	}
	public void setLimit(int limit) {
		this.limit = limit;
	}
	public String getSignalDirection() {
		return signalDirection;
	}
	public void setSignalDirection(String signalDirection) {
		this.signalDirection = signalDirection;
	}
	public int getNoOfVehicles() {
		return noOfVehicles;
	}
	public void setNoOfVehicles(int noOfVehicles) {
		this.noOfVehicles = noOfVehicles;
	}
	@Override
	public int compare(Signal s1, Signal s2) {
		return Integer.compare(s2.noOfVehicles, s1.noOfVehicles);
	}
	
	
	
}
