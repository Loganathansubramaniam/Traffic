package com.demo.traffic.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Service;

import com.demo.traffic.config.TrafficConfiguration;
import com.demo.traffic.model.Signal;
import com.demo.traffic.model.TrafficModel;
import com.demo.traffic.service.TrafficService;

@Service
public class TrafficServiceImpl implements TrafficService{
	
	@Autowired
	private CacheManager cacheManager;
	
	@Autowired
	private TrafficConfiguration trafficConfig;

	@Override
	public Queue<Signal> getTrafficQueue() {
		TrafficModel tm = (TrafficModel) cacheManager.getCache("signal");
		if(tm.getQueue().size() == 0){
			cacheManager.getCache("signal").put("traffic", getCurrentTraffic(tm));
		}else{
			Queue<Signal> cachedTraffic = sortQueue(convertToQueueOfSignal());
			//clear the cache
			cacheManager.getCache("signal").clear();
			
			TrafficModel t = new TrafficModel("signal");
			Queue<Signal> currentTraffic = sortQueue(getCurrentTraffic(t));
			
			if(cachedTraffic.peek().getSignalDirection().equalsIgnoreCase(currentTraffic.peek().getSignalDirection())){
				if(currentTraffic.peek().getLimit() >= trafficConfig.getLimitPerDirection()){
					currentTraffic.poll();//Remove from the queue as limit reached. Preference to be given to other directions
					currentTraffic.peek().setGreen(true);//Make the next entry in the queue direction as green
					System.out.println("queue removed:"+ currentTraffic.size());
				}else{
					currentTraffic.peek().setLimit(currentTraffic.peek().getLimit()+1);
				}
			}
			cacheManager.getCache("signal").put("traffic", currentTraffic);
		}
		return sortQueue(convertToQueueOfSignal());
	}
	
	private Queue<Signal> convertToQueueOfSignal(){
		Queue<Signal> queueSignal = new LinkedList<>();
		
		@SuppressWarnings("unchecked")
		ConcurrentHashMap<Object, Object>  signalMap = (ConcurrentHashMap<Object, Object>)cacheManager.getCache("signal").getNativeCache();
		for(Map.Entry<Object, Object> entry : signalMap.entrySet()){
			@SuppressWarnings("unchecked")
			LinkedList<Signal> signalLL = (LinkedList<Signal>) entry.getValue();
			for(Signal signal : signalLL){
				queueSignal.add(signal);
			}
		}
		return queueSignal;
	}
	
	private Queue<Signal> sortQueue(Queue<Signal> finalQueue) {
		List<Signal> signalList = new ArrayList<>();
		for(Signal s : finalQueue){
			signalList.add(s);
		}
		Collections.sort(signalList, new Signal());
		return new LinkedList<>(signalList);
	}

	private Queue<Signal> getCurrentTraffic(TrafficModel trafficModel){
		Queue<Signal> trafficQueue = trafficModel.getQueue();
		updateTrafficQueue(trafficQueue);
		List<Signal> signalList = new ArrayList<>();
		for(Signal q : trafficQueue){
			Random random = new Random();
			q.setNoOfVehicles(random.nextInt(trafficConfig.getRandomNumberConfig()));
			q.setLimit(q.getLimit()+1);
			signalList.add(q);
		}
		Collections.sort(signalList, new Signal());
		Queue<Signal> finalQueue = new LinkedList<>(signalList);
		finalQueue.peek().setGreen(true);
		return finalQueue;
	}
	
	private void updateTrafficQueue(Queue<Signal> queue){
		Signal s1 = new Signal("East");
		Signal s2 = new Signal("West");
		Signal s3 = new Signal("North");
		Signal s4 = new Signal("South");
		queue.add(s1);
		queue.add(s2);
		queue.add(s3);
		queue.add(s4);
	}

}
