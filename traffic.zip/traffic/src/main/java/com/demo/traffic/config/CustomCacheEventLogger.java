package com.demo.traffic.config;

public class CustomCacheEventLogger {
	

}
