package com.demo.traffic.controller;

import java.util.Queue;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.demo.traffic.model.Signal;
import com.demo.traffic.service.TrafficService;

@RestController("getTrafficInfo")
public class TrafficController {
	
	@Autowired
	TrafficService trafficService;
	
	@RequestMapping(method=RequestMethod.GET)
	private Queue<Signal> getTrafficInfo(HttpServletRequest req, HttpServletResponse res){
		return trafficService.getTrafficQueue();
	}

}
